[{:outcome=>:red, :time=>[2012, 11, 3, 12, 30, 10], :number=>1}]
