
public class Untitled
{
    public static int Answer
    {
        get { return 42; }
    }
}
