
def answer
  42
end
