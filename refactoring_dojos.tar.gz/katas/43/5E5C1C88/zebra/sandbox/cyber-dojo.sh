python *test*.py
