#Generated file - cleanAll.sh
echo "Running cleanAll for CppUTest v2.4a created on 2012-04-05-09-29"
export CPPUTEST_HOME=$(pwd)
echo "export CPPUTEST_HOME=$(pwd)/"
make cleanEverythingInstall
