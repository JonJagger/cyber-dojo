extern "C"
{
#include "ClassName.h"
}

#include "CppUTest/TestHarness.h"

TEST_GROUP(ClassName)
{
    void setup()
    {
    }

    void teardown()
    {
    }
};

TEST(ClassName, Create)
{
  FAIL("Start here");
}

