#ifndef UNTITLED_INCLUDED
#define UNTITLED_INCLUDED

int hhg();

#endif
